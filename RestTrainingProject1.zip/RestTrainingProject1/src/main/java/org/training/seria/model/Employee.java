
package org.training.seria.model;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

/**
 * @author ruchi
 *
 */

@XmlRootElement(name="employee")
public class Employee {

	/**
	 * @param args
	 */
	private int id;
	private String fname;
	private String lname;
	private String dept;
	private String location;
	
	
		
    public Employee() {
		super();
	}

	public Employee(int id, String fname, String lname, String dept,
			String location) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.dept = dept;
		this.location = location;
	}

	@XmlElement (name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@XmlElement (name="first-name")
	public String getFname() {
		return fname;
	}

	
	public void setFname(String fname) {
		this.fname = fname;
	}

	@XmlElement (name="last-name")
	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@XmlElement (name="department")
	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	@XmlElement (name="location")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	public String toString(){
		return this.getId()+"\t"+ this.getFname()+"\t" + this.getLname()+"\t"+ this.getLocation()+"\t"+ this.getDept();
	}

		
}
