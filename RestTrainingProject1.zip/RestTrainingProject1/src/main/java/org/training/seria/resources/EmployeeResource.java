package org.training.seria.resources;

import java.net.URI;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.training.seria.exception.BusinessException;
import org.training.seria.exception.Error;
import org.training.seria.model.*;
import org.training.seria.service.EmployeeService;


@Path("employees")
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class EmployeeResource {
	
	EmployeeService es = new EmployeeService();
	
	@GET 
    public List<Employee> getEmployees() {
		return es.getEmployees();
    }
	
	
	@POST
	public Response addEmployee(Employee employee){
		Employee newEmployee = es.addEmployee(employee);
		return Response.status(Status.CREATED).
				entity(newEmployee).
				build();
	}
	
	
	@GET
	@Path("/{id}")
    public Response getEmployee(@PathParam ("id") Integer id) {
		if (es.getEmployee(id) == null){
			throw new BusinessException(Status.NOT_FOUND.getStatusCode(),"Employee with id " + id + " not found");
		}
		return Response.ok(es.getEmployee(id)).build();
    }
	
	
	@PUT
	@Path("/{id}")
	public Response updateEmployee(@PathParam ("id") Integer id,Employee employee){
		Employee updatedEmployee = es.updateEmployee(id,employee);
		return Response.status(Status.OK).
				entity(updatedEmployee).
				build();
	}
	
	@DELETE
	@Path("/{id}")
	public Response deleteEmployee(@PathParam ("id") Integer id) {
		if(es.getEmployee( id) == null){
			Error error =  new Error(Status.NOT_FOUND.getStatusCode(), "Employee with the id " + id + " not found");
			Response response = Response.status(error.getErrorCode()).entity(error).build();
			throw new WebApplicationException(response);
		}
		es.deleteEmployee(id);
		return Response.ok().build();
    }
	
	
	@POST
	@Path("UriInfo")
	public Response addEmployeeReturningUriInfo(Employee employee, @Context UriInfo uriInfo){
		Employee newEmployee = es.addEmployee(employee);
		
		URI uri = uriInfo.getAbsolutePathBuilder().path(String.valueOf(newEmployee.getId())).build();
		
		return Response.created(uri).status(Status.CREATED).
				entity(newEmployee).
				build();
	}
	
	@GET
	@Path("HeaderInfo")
	@Produces(MediaType.TEXT_PLAIN)
	public String getHeaderInfo(@Context HttpHeaders header){
		
		MultivaluedMap<String,String> requestHeaders = header.getRequestHeaders();
		return "user is " + requestHeaders.get("user");

	}
	


}
