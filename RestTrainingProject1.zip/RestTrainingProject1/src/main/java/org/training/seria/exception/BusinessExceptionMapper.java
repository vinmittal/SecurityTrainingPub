package org.training.seria.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class BusinessExceptionMapper implements ExceptionMapper<BusinessException>{

	@Override
	public Response toResponse(BusinessException exception) {
		
		Error error =  new Error(exception.getCode(), exception.getMessage());
		return Response.status(error.getErrorCode()).entity(error).build();
	}

}
