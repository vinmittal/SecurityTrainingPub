package org.training.seria.exception;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Error {
	int errorCode;
	String errorMessage;
	
	
	public Error() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Error(int errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
