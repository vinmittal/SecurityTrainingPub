package org.training.seria.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.training.seria.db.DBClass;
import org.training.seria.model.Employee;

public class EmployeeService {
	
	private Map<Integer,Employee> employees = DBClass.getEmployees();
	

	public EmployeeService() {
		super();
				
	}
	
	public List<Employee> getEmployees(){
		return new ArrayList<Employee>(employees.values());
	}
	
	
	public Employee addEmployee(Employee employee){
		employee.setId(employees.size()+1);
		employees.put(employees.size()+1, employee);
		return employee;
	}
	
	public Employee getEmployee(Integer id){
		return employees.get(id);
	}

	public Employee updateEmployee(Integer id, Employee employee) {
		
		Employee emp = employees.get(id);
		if (emp != null){
			emp.setDept(employee.getDept());
			emp.setFname(employee.getFname());
			emp.setLname(employee.getLname());
			emp.setLocation(employee.getLocation());
			employees.put(id, emp);
		}
		
		return emp;
	}

	public void deleteEmployee(Integer id) {
		Employee emp = employees.get(id);
		if (emp != null){
			employees.remove(id);
		}
		
	}
	
	
}
