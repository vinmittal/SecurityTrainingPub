package org.training.seria.db;

import java.util.HashMap;
import java.util.Map;

import org.training.seria.model.Employee;

public class DBClass {
	
	private static Map<Integer,Employee> employees = new HashMap<Integer,Employee>();

	public static Map<Integer, Employee> getEmployees() {
		return employees;
	}

	public static void setEmployees(Map<Integer, Employee> employees) {
		DBClass.employees = employees;
	}
	
	
}
