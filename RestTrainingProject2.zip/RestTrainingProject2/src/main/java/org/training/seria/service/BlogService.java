package org.training.seria.service;

import java.util.ArrayList;
import java.util.List;

import org.training.seria.model.Blog;
import org.training.seria.model.Employee;


public class BlogService {
	
	private EmployeeService es =  new EmployeeService();

	
	public List<Blog> getBlogs(int employeeId){
		Employee emp = es.getEmployee(employeeId);
		return new ArrayList<Blog>(emp.getBlogsMap().values());
			
	}
	
	
	public Blog getBlog(int employeeId, int blogId){
		Employee emp = es.getEmployee(employeeId);
		return emp.getBlogsMap().get(blogId);
			
	}
	
	
	public Blog addBlog(Blog blog, int employeeId){
		
		Employee emp = es.getEmployee(employeeId);
		blog.setId(emp.getBlogsMap().size()+1);
		emp.getBlogsMap().put(blog.getId(), blog);
		return blog;
		
	}
}
