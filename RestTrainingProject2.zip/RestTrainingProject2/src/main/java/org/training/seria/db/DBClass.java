package org.training.seria.db;

import java.util.HashMap;
import java.util.Map;

import org.training.seria.model.Employee;
import org.training.seria.model.Project;

public class DBClass {
	
	private static Map<Integer,Employee> employees = new HashMap<Integer,Employee>();
	
	private static Map<Integer,Project> projects = new HashMap<Integer,Project>();
	
	

	public static Map<Integer, Employee> getEmployees() {
		return employees;
	}

	public static void setEmployees(Map<Integer, Employee> employees) {
		DBClass.employees = employees;
	}

	public static Map<Integer, Project> getProjects() {
		return projects;
	}

	public static void setProjects(Map<Integer, Project> projects) {
		DBClass.projects = projects;
	}
	
	
}
