package org.training.seria.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.training.seria.model.Blog;
import org.training.seria.model.Employee;
import org.training.seria.service.BlogService;
import org.training.seria.service.EmployeeService;

@Path("/")
public class BlogResource {
	
	private BlogService bs =  new BlogService();
	private EmployeeService es =  new EmployeeService();
	
	
	@GET 
	public List<Blog> getBlog(@PathParam ("employeeId") Integer employeeId){
		
		return bs.getBlogs(employeeId);
		
	}
	
	@GET
	@Path("{blogId}")
	public Blog getBlog(@PathParam ("employeeId") Integer employeeId, @PathParam ("blogId") Integer blogId ){
		return   bs.getBlog(employeeId, blogId);
	}
	
	
	@POST
	public void addBlog(@PathParam ("employeeId") Integer employeeId, Blog blog, @Context UriInfo uriInfo){
		Blog createdBlog = bs.addBlog(blog, employeeId);
		
		Employee emp = es.getEmployee(employeeId);
		String url = uriInfo.getAbsolutePathBuilder()
				.path(BlogResource.class)
				.path(String.valueOf(createdBlog.getId()))
				.build()
				.toString();
		emp.addLink(url, "blog");
	
	}
	
	
}
