package org.training.seria.resources;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.training.seria.exception.BusinessException;
import org.training.seria.exception.Error;
import org.training.seria.model.*;
import org.training.seria.service.ProjectService;


@Path("projects")
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class ProjectResource {
	
	ProjectService ps = new ProjectService();
	
	@GET 
    public List<Project> getProjects() {
		return ps.getProjects();
    }
	
	
	@POST
	public Response addProject(Project project){
		Project newProject = ps.addProject(project);
		return Response.status(Status.CREATED).
				entity(newProject).
				build();
	}
	
	
	@GET
	@Path("/{id}")
    public Response getProject(@PathParam ("id") Integer id) {
		if (ps.getProject(id) == null){
			throw new BusinessException(Status.NOT_FOUND.getStatusCode(),"Project with id " + id + " not found");
		}
		return Response.ok(ps.getProject(id)).build();
    }
	
	
	@PUT
	@Path("/{id}")
	public Response updateProject(@PathParam ("id") Integer id,Project project){
		Project updatedProject = ps.updateProject(id,project);
		return Response.status(Status.CREATED).
				entity(updatedProject).
				build();
	}
	
	@DELETE
	@Path("/{id}")
	public Response deleteProject(@PathParam ("id") Integer id) {
		if(ps.getProject( id) == null){
			Error error =  new Error(Status.NOT_FOUND.getStatusCode(), "Project with the id " + id + " not found");
			Response response = Response.status(error.getErrorCode()).entity(error).build();
			throw new WebApplicationException(response);
		}
		ps.deleteProject(id);
		return Response.ok().build();
    }
	
	
}
