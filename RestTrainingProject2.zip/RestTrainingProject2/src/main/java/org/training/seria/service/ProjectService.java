package org.training.seria.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.training.seria.db.DBClass;
import org.training.seria.model.Project;

public class ProjectService {
	
	private Map<Integer,Project> projects = DBClass.getProjects();
	

	public ProjectService() {
		super();
				
	}
	
	public Map<Integer,Project> getProjectsMap(){
		return projects;
	}
	
	public List<Project> getProjects(){
		return new ArrayList<Project>(projects.values());
	}
	
	
	public Project addProject(Project project){
		project.setId(projects.size()+1);
		projects.put(projects.size()+1, project);
		return project;
	}
	
	public Project getProject(Integer id){
		return projects.get(id);
	}

	public Project updateProject(Integer id, Project project) {
		
		Project proj = projects.get(id);
		if (proj != null){
			proj.setName(project.getName());
			proj.setDescription(project.getDescription());
			projects.put(id, proj);
		}
		return proj;
	}

	public void deleteProject(Integer id) {
		Project proj = projects.get(id);
		if (proj != null){
			projects.remove(id);
		}
		
	}
	
	
}
