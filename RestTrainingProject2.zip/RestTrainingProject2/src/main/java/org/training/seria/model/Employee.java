
package org.training.seria.model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * @author ruchi
 *
 */

@XmlRootElement(name="employee")
public class Employee {

	/**
	 * @param args
	 */
	private int id;
	private String fname;
	private String lname;
	private String dept;
	private String location;
	private Map<Integer,Project> projectsMap = new HashMap<Integer,Project>();
	
	private Map<Integer,Blog> blogsMap = new HashMap<Integer,Blog>();
	
	private List<Link> links = new ArrayList<Link>();
	
		
    public Employee() {
		super();
	}

	public Employee(int id, String fname, String lname, String dept,
			String location) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.dept = dept;
		this.location = location;
	}

	@XmlElement (name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@XmlElement (name="first-name")
	public String getFname() {
		return fname;
	}

	
	public void setFname(String fname) {
		this.fname = fname;
	}

	@XmlElement (name="last-name")
	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@XmlElement (name="department")
	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	@XmlElement (name="location")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	public String toString(){
		return this.getId()+"\t"+ this.getFname()+"\t" + this.getLname()+"\t"+ this.getLocation()+"\t"+ this.getDept();
	}

	@XmlTransient
	public Map<Integer, Project> getProjectsMap() {
		return projectsMap;
	}

	public void setProjectsMap(Map<Integer, Project> projectsMap) {
		this.projectsMap = projectsMap;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}
	
	public void addLink(String url, String rel){
		Link link = new Link(url,rel);
		this.links.add(link);
		
	}

	@XmlTransient
	public Map<Integer, Blog> getBlogsMap() {
		return blogsMap;
	}

	public void setBlogsMap(Map<Integer, Blog> blogsMap) {
		this.blogsMap = blogsMap;
	}
	
	
	
			
}
